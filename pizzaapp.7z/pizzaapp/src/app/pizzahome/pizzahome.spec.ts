import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Pizzahome } from './pizzahome';

describe('Pizzahome', () => {
  let component: Pizzahome;
  let fixture: ComponentFixture<Pizzahome>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Pizzahome]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Pizzahome);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
