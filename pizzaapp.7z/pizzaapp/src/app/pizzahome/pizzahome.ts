import { Component } from '@angular/core';

@Component({
  selector: 'app-pizzahome',
  imports: [],
  templateUrl: './pizzahome.html',
  styleUrl: './pizzahome.css',
})
export class Pizzahome {

}
