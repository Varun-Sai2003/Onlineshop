import { CanActivateFn } from '@angular/router';

export const asgardGuard: CanActivateFn = (route, state) => {
  if(sessionStorage.getItem("uid")!=null)
  {
    return true;
  }
  else{
    return false;
  }
};
