import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { checkalphebet } from '../contact/myvalidations';

@Component({
  selector: 'app-contact',
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './contact.html',
  styleUrl: './contact.css',
})
export class Contact {
frm:any;

constructor(){
  this.frm = new FormGroup({
    uname : new FormControl("",[Validators.required, Validators.pattern("[a-zA-Z ]+")]),
    email : new FormControl("",[Validators.required, Validators.email]),
    message : new FormControl("Type your message here", [Validators.required, Validators.maxLength(200)])
  })
}

}
