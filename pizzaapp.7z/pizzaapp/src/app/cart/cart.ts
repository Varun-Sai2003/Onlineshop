import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { DiscountPipe } from '../discount-pipe';
import { CurrencyPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Pizzaonline } from '../pizzaonline';

@Component({
  selector: 'app-cart',
  imports: [DiscountPipe, CurrencyPipe, CommonModule, FormsModule],
  templateUrl: './cart.html',
  styleUrl: './cart.css',
})
export class Cart {
  pid: any;
  pname: any;
  price: any;
  desc: any;
  imge: any;
  q: number = 0;
  constructor(private ob: ActivatedRoute, private obj: Pizzaonline) {
    ob.queryParams.subscribe((d) => {
      (this.pid = d['a1']),
        (this.pname = d['a2']),
        (this.desc = d['a3']),
        (this.price = d['a4']),
        (this.imge = d['a5']);
    });
  }

  Buy(frm: any) {
    const order = {
      pizzaid: this.pid,
      transdate: new Date().toLocaleDateString('EN-CA'),
      qty: parseInt(frm.qty),
      username: sessionStorage.getItem('uid'),
    };
    this.obj.Buypizza(order).subscribe((data) => {
      console.log(data);
    });
  }

}
