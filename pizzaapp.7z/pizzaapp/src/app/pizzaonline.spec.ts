import { TestBed } from '@angular/core/testing';

import { Pizzaonline } from './pizzaonline';

describe('Pizzaonline', () => {
  let service: Pizzaonline;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Pizzaonline);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
