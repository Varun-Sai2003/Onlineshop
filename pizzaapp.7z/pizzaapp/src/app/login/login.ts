import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Pizzaonline } from '../pizzaonline';

@Component({
  selector: 'app-login',
  imports: [FormsModule,CommonModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {

  constructor(private r:Router, private p:Pizzaonline)
  {
  }
  error: string = '';

  validate(f: any) {
    const loginData = {
      uname: f.value.uid,
      pwd: f.value.pwd,
    };

    this.p.Login(loginData).subscribe(
      (response: any) => {
        if (response.success) {
          sessionStorage.setItem('uid', loginData.uname);
          this.r.navigate(['/menu']);
        } else {
          this.error = 'Invalid Credentials';
        }
      },
      (error) => {
        this.error = 'An error occurred during login. Please try again.';
        console.error(error);
      }
    );
  }

}
