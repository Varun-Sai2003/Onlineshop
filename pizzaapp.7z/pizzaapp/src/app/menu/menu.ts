import { CommonModule, NgOptimizedImage } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from "@angular/router";
import { Pizzadata } from '../pizzadata';
import { DiscountPipe } from '../discount-pipe';
import { Pizzaonline } from '../pizzaonline';
import { HttpClient,  } from '@angular/common/http';

@Component({
  selector: 'app-menu',
  imports: [CommonModule, RouterLink, DiscountPipe,],
  templateUrl: './menu.html',
  styleUrl: './menu.css',
})
export class Menu {
 res: any;
 pizzas:any;
  constructor(private ob:Pizzadata, private obj:Pizzaonline,)
  {
   this.res = ob.add(10,20);
  //  this.pizzas=ob.pizzadetails;
    obj.showAllpizza().subscribe(res => this.pizzas=res);
  }



}
