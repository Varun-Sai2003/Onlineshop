import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'discount'
})
export class DiscountPipe implements PipeTransform {

  // transform(value: unknown, ...args: unknown[]): unknown {
  //   return null;
  // }
  transform(x : number, ...args: number[])
  {
    let d = args[0];
    let dp = x - (x*d/100);
    return dp;
  }

}
