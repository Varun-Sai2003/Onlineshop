import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class Pizzaonline {
constructor(private ob:HttpClient){}
showAllpizza():Observable<any>{
  return this.ob.get("https://localhost:7057/api/MyPizza/showall");
}

AddNewuser(frm:any):Observable<any>{
  return this.ob.post("https://localhost:7057/api/MyPizza/Adduser",frm);
}

Login(data:any):Observable<any>{
  return this.ob.post("https://localhost:7057/api/MyPizza/login",data);
}


Buypizza(data:any):Observable<any>{
  return this.ob.post("https://localhost:7057/api/MyPizza/login/Buy",data);
}
}
