import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Home } from "./home/home";
import { Login } from "./login/login";
import { Cart } from "./cart/cart";

@Component({
  selector: 'app-root',
  imports: [Home, Login, Cart],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  protected readonly title = signal('pizzaapp');

  sid: number = 12345;
  sname: string = 'Ravan';
  url: string = 'http://google.com';
  cls: string = 'hi';
  b: boolean = false;
  bold: string = 'font-weight:bold;';

  myfunc() {
    let mycss = {
      hi: true,
      welcome: true,
    };
    return mycss;
  }

  mystyle() {
    let mystyles = {
      'font-weight':'bold',
      color: 'red',
    };
    return mystyles;
  }
}
