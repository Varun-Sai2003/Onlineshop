import { Routes } from '@angular/router';
import { Home } from './home/home';
import { Login } from './login/login';
import { Menu } from './menu/menu';
import { Pizzahome } from './pizzahome/pizzahome';
import { Cart } from './cart/cart';
import { Register } from './register/register';
import { Pagenotfound } from './pagenotfound/pagenotfound';
import { asgardGuard } from './asgard-guard';
import { Contact } from './contact/contact';

export const routes: Routes = [
  {
    path: 'login',
    component: Login
  },
  {
    path: 'menu',
    component: Menu
  },
  {
    path: 'pizzahome',
    component:Pizzahome
  },
  {
    path: 'cart',
    component:Cart, canActivate:[asgardGuard]
  },
  {
    path: 'register',
    component:Register
  },
  {
    path:'home',
    component:Home
  },
  {
    path:'contact',
    component:Contact
  },
  {
    path: '**',
    component:Pagenotfound
  }
];
