import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Pizzaonline } from '../pizzaonline';
@Component({
  selector: 'app-register',
  imports: [CommonModule, FormsModule],
  templateUrl: './register.html',
  styleUrl: './register.css',
})
export class Register {

  constructor(private ob:Pizzaonline){}
Adduser(frm: any) {
this.ob.AddNewuser(frm).subscribe(res=>alert("New User Registered Successfully") );
}

}
